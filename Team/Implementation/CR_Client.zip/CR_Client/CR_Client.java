import java.net.*;
import java.io.*;
import java.util.Arrays;
/**
 * Write a description of class CR_Client here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CR_Client{
   private Socket socket = null;
   private DataInputStream console = null;
   private DataOutputStream streamOut = null;
   
   private final String[] quitList = {"Bye", "Bye.", "Bye!", "bye", "bye.", "bye!"};
   
   public CR_Client(String serverName, int serverPort){
      System.out.println("Establishing connection. Please wait ...");
      try{
         socket = new Socket(serverName, serverPort);
         System.out.println("Connected: " + socket);
         start();
      }
      catch(UnknownHostException uhe){System.out.println("Host unknown: " + uhe.getMessage());}
      catch(IOException ioe){System.out.println("Unexpected exception: " + ioe.getMessage());}
      
      String line = "";
      //while (!line.equals(".bye")){}
      while(!(Arrays.asList(quitList).contains(line))){
         try{
            line = console.readLine();
            streamOut.writeUTF(line);
            streamOut.flush();
         }
         catch(IOException ioe){System.out.println("Sending error: " + ioe.getMessage());}
      }
   }
   
   public void start() throws IOException{
      console = new DataInputStream(System.in);
      streamOut = new DataOutputStream(socket.getOutputStream());
   }
   
   public void stop(){
      try{
         if (console != null){console.close();}
         if (streamOut != null){streamOut.close();}
         if (socket != null){socket.close();}
      }
      catch(IOException ioe){System.out.println("Error closing ...");}
   }
   public static void main(String args[])
   {  CR_Client client = null;
      if(args.length != 2){System.out.println("Usage: java ChatClient host port");}
      else{client = new CR_Client(args[0], Integer.parseInt(args[1]));}
   }
}
