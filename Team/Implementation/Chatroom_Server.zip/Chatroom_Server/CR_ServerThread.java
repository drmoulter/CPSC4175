import java.net.*;
import java.io.*;
/**
 * Write a description of class CR_ServerThread here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CR_ServerThread extends Thread{
   private Socket socket = null;
   private CR_Server server = null;
   private int ID = -1;
   private DataInputStream streamIn = null;

   public CR_ServerThread(CR_Server _server, Socket _socket){
       server = _server;  socket = _socket;  ID = socket.getPort();
   }
   
   public void run(){
      System.out.println("Server Thread " + ID + " running.");
      while(true){
         try{System.out.println(streamIn.readUTF());}
         catch(IOException ioe){}
      }
   }
   
   public void open() throws IOException{
       streamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
   }
   
   public void close() throws IOException{
      if (socket != null){socket.close();}
      if (streamIn != null){streamIn.close();}
   }
}
