import java.net.*;
import java.io.*;
import java.util.Arrays;
/**
 * Write a description of class CR_Server here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CR_Server implements Runnable{
    private CR_ServerThread clients[] = new CR_ServerThread[50];
    private ServerSocket server = null;
    private Thread thread = null;
    private int clientCount = 0;
    //private Socket socket = null;
    //private DataInputStream streamIn = null;

    private final String[] quitList = {"Bye", "Bye.", "Bye!", "bye", "bye.", "bye!"};

    public CR_Server(int port){
        try{
            System.out.println("Binding to port " + port + ", please wait  ...");
            server = new ServerSocket(port);  
            System.out.println("Server started: " + server);
            start();
        }
        catch(IOException ioe){System.err.println("Can not bind to port " + port + ": " + ioe.getMessage());}
    }

    public void run(){
        while(thread != null){
            try{
                System.out.println("Waiting for a client. . .");
                addThread(server.accept());
            }
            catch(IOException ioe){System.err.println("Acceptance Error: " + ioe);}
        }
    }

    //One client runnable
    /*public void run(){
    while (thread != null){
    try{
    System.out.println("Waiting for a client ..."); 
    socket = server.accept();
    System.out.println("Client accepted: " + socket);
    open();
    boolean done = false;
    while(!done){
    try{
    String line = streamIn.readUTF();
    System.out.println(line);
    //done = line.equals(".bye");
    done = Arrays.asList(quitList).contains(line);
    }
    catch(IOException ioe){done = true;}
    }
    close();
    }
    catch(IOException ie){System.out.println("Acceptance Error: " + ie);}
    }
    }*/
    
    //Non-response addThread
    /*public void addThread(Socket socket){
    System.out.println("Client accepted: " + socket);
    client = new CR_ServerThread(this, socket);
    try{
    client.open();
    client.start();
    }
    catch(IOException ioe){System.out.println("Error opening thread: " + ioe);}
    }*/
    
    public void addThread(Socket socket){
        if(clientCount < clients.length){
            System.out.println("Client accepted: " + socket);
            clients[clientCount] = new CR_ServerThread(this, socket);
            try{
                clients[clientCount].open();
                clients[clientCount].start();
                clientCount++;
            }
            catch(IOException ioe){System.err.println("Error opening thread: " + ioe);}
        }
        else{System.err.println("Client refused: room is full");}
    }
    
    public void start(){
        if(thread == null){
            thread = new Thread(this); 
            thread.start();
        }
    }

    public void stop(){
        if(thread != null){
            thread.stop(); 
            thread = null;
        }
    }

    private int findClient(int ID){
        for(int i = 0; i < clientCount; i++){
            if(clients[i].getID() == ID){return i;}
        }
        return -1;
    }

    public synchronized void handle(int ID, String input){
        if(Arrays.asList(quitList).contains(input)){
            clients[findClient(ID)].send(input);
            remove(ID);
        }
        else{
            for(int i = 0; i < clientCount; i++){clients[i].send(ID + ": " + input);}
        }
    }

    public synchronized void remove(int ID){
        int pos = findClient(ID);
        if(pos >= 0){
            CR_ServerThread toTerminate = clients[pos];
            System.out.println("Removing client thread " + ID + " at " + pos);

            if(pos < clientCount-1){
                for(int i = pos+1; i < clientCount; i++){clients[i-1] = clients[i];}
            }

            clientCount--;
            try{toTerminate.close();}
            catch(IOException ioe){System.err.println("Error closing thread: " + ioe);}
            toTerminate.stop();
        }
    }

    /*public void open() throws IOException{
    streamIn = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
    }*/

    /*public void close() throws IOException{
    if (socket != null){socket.close();}
    if (streamIn != null){streamIn.close();}
    }*/

    public static void main(String args[]){
        CR_Server server = null;
        if(args.length != 1){System.out.println("Usage: java CR_Server port");}
        else{server = new CR_Server(Integer.parseInt(args[0]));}
    }
}
